class StaticKeys {
  StaticKeys._();

  static const String keyMobileNumber = "KEY_MOBILE_NUMBER";

}
