class Strings {
  Strings._();

  static const String appName = "Serenestream";
  static const String temp = "It was popularised in the 1960s with the release of Letraset sheetscontaining Lorem Ipsum.";

  static const String strCreateAccount =
      "Create Account";
  static const String strLogin = "Log In";
  static const String signIn = "Sign In";
  static const String or = "Or";
  static const String chooseGender = "Choose your ";
  static const String gender = "gender";
  static const String and = "and";
  static const String overcoming_depression = "Overcoming\nDepression";
  static const String tackling_stress = "\t\tTackling\n\t\tStress";
  static const String what_can_help = "What can we \n help you with";
  static const String how_feeling = "How are you  \n feeling?";
  static const String male = "Male";
  static const String happy = "Happy";
  static const String sad = "Sad";
  static const String normal = "Normal";
  static const String mad = "Mad";
  static const String female = "Female";
  static const String strContinue = "Continue";
  static const String submitting = "Submitting...";
  static const String submit = "Submit";
  static const String strVerify = "Verify OTP";
  static const String strRegister = "Register";
  static const String forgetPassword = "Forget Password?";
  static const String strForgetPassword = "Forget Password";
  static const String resetPassword = "Reset Password";
  static const String strWithYourMobileNumber = "with your mobile number";
  static const String termsConditions ="Terms & Services";
  static const String hours_sleep ="How many hours \n do you sleep?";


  static const String hintName = "Name";
  static const String hintPassword = "Password";
  static const String hintConfirmPassword = "Confirm Password";
  static const String hintEmailPhone = "Email";
  static const String enterOtp = "Enter OTP";
  static const String strCompleteYourProfile = "Complete Your Profile";
  static const String enterCodeMsg = "Enter the OTP code we just sent you on your registered Email/Phone number";
  static const String didNotReceiveOtp = "Didn't get OTP?";
  static const String resendOtp = "Resend OTP";
  static const String splashText = "Healthy life is having a healthy mind so build a healthy mind then the healthy body.";

  static const String strDontHaveAnAccount = "Don't have an account?";
  static const String strAlreadyHaveAnAccount = "Do you have an account?";
  static const apiSorryMessage = "Sorry! Something went wrong";
  static const String dashboard = "Dashboard";
  static const String getStarted = "Get Started";

  static const String logout = "Logout";
  static const String signUp = "Sign Up";
  static const String cancel = "Cancel";
  static const String logoutMsg = "Logout Successful!";
  static const String privacyPolicy = "Privacy Policy";
  static const String termAgree = "I’m agree to The";


}
