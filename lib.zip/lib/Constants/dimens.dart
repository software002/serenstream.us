import 'package:flutter_screenutil/flutter_screenutil.dart';

class Dimens {
  Dimens._();

  //for all screens
  static double horizontal_padding = 15.w;
  static double vertical_padding = 25.h;
}
